import Link from 'next/link'

export default function Page(){
  return (
    <div style={{padding:24}}>
      <h1>Tasks</h1>
      <p>Worker tasks (3³DTD) — placeholder</p>
      <p><Link href="/ship/work/core/tasks">Open</Link></p>
    </div>
  )
}
