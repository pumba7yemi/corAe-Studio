// apps/life/lib/life-config.ts
export type LifeDoor = "home" | "work" | "business";

export const LIFE_DOORS: LifeDoor[] = ["home", "work", "business"];