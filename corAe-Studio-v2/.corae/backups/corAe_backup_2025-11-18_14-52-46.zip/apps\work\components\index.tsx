export { default as WorkSystemBuilderBadge } from './WorkSystemBuilderBadge';
export { default } from './WorkSystemBuilderBadge';
