export const dynamic = "force-dynamic";

import React from "react";
import Utilize from "@/app/ship/_shared/wizard/Utilize";

export default function Page() {
  return <Utilize scope="work" />;
}
