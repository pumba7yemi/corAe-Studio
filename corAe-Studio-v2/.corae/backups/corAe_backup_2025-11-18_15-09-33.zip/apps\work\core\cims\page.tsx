import Link from 'next/link'

export default function Page(){
  return (
    <div style={{padding:24}}>
      <h1>Work CIMS</h1>
      <p>Worker CIMS placeholder</p>
      <p><Link href="/ship/work/core/cims">Open</Link></p>
    </div>
  )
}
